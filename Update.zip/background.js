chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "preguntarSobreTexto",
    title: "Preguntar sobre el texto",
    contexts: ["selection"]
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "preguntarSobreTexto") {
    if (tab.url.startsWith("chrome-extension://") || tab.url.startsWith("file://")) {
      // Para PDFs y otros archivos locales
      chrome.storage.local.set({textoSeleccionado: info.selectionText}, () => {
        abrirPopup();
      });
    } else {
      // Para páginas web normales
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        function: getSelectedText,
      }, (injectionResults) => {
        if (chrome.runtime.lastError) {
          console.error(chrome.runtime.lastError);
          return;
        }
        const [{ result }] = injectionResults;
        if (result) {
          chrome.storage.local.set({textoSeleccionado: result}, () => {
            abrirPopup();
          });
        } else {
          console.error("No se recibió una selección válida");
        }
      });
    }
  }
});

function getSelectedText() {
  return window.getSelection().toString();
}

function abrirPopup() {
  chrome.windows.create({
    url: chrome.runtime.getURL("popup.html"),
    type: "popup",
    width: 400,
    height: 600
  });
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "getSelection") {
    sendResponse({selection: request.selection});
  }
  return true;
});
