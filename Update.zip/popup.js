const API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent";

let API_KEY = "AIzaSyC06Rv5sS35s7gCAhvoyrZkqZXFtExamec";
let TEMPERATURE = 0.5;
let MAX_TOKENS = 1000;

function toggleHerramientasMenu() {
  const menu = document.getElementById('herramientasMenu');
  menu.style.display = menu.style.display === 'none' ? 'block' : 'none';
}

function guardarConfiguracion() {
  const apiKey = document.getElementById('apiKey').value.trim();
  const temperature = parseFloat(document.getElementById('temperature').value);
  const maxTokens = parseInt(document.getElementById('maxTokens').value);

  if (apiKey) {
    API_KEY = apiKey;
  }
  if (!isNaN(temperature) && temperature >= 0 && temperature <= 1) {
    TEMPERATURE = temperature;
  }
  if (!isNaN(maxTokens) && maxTokens > 0) {
    MAX_TOKENS = maxTokens;
  }

  chrome.storage.sync.set({ apiKey: API_KEY, temperature: TEMPERATURE, maxTokens: MAX_TOKENS }, () => {
    toggleHerramientasMenu();
  });
}

async function enviarPreguntaAGemini(contexto, pregunta) {
  try {
    const response = await fetch(`${API_URL}?key=${API_KEY}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        contents: [{
          parts: [{
            text: `Contexto: ${contexto}\nPregunta: ${pregunta}`
          }]
        }],
        generationConfig: {
          temperature: TEMPERATURE,
          maxOutputTokens: MAX_TOKENS,
        }
      }),
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    return data.candidates[0].content.parts[0].text;
  } catch (error) {
    console.error('Error al generar contenido:', error);
    throw error;
  }
}

async function generarPreguntasAutomaticas(texto) {
  try {
    const respuesta = await enviarPreguntaAGemini(texto, "Genera 3 preguntas relevantes sobre este texto, separadas por saltos de línea.");
    return respuesta.split('\n').filter(pregunta => pregunta.trim() !== '');
  } catch (error) {
    console.error('Error al generar preguntas automáticas:', error);
    return [];
  }
}

function mostrarPreguntasAutomaticas(preguntas) {
  const contenedorPreguntas = document.getElementById('preguntasAutomaticas');
  contenedorPreguntas.innerHTML = '';
  preguntas.forEach(pregunta => {
    const botonPregunta = document.createElement('button');
    botonPregunta.textContent = pregunta;
    botonPregunta.classList.add('pregunta-automatica');
    botonPregunta.addEventListener('click', () => {
      document.getElementById('pregunta').value = pregunta;
    });
    contenedorPreguntas.appendChild(botonPregunta);
  });
}

function copiarRespuesta() {
  const respuesta = document.getElementById('respuesta').textContent;
  navigator.clipboard.writeText(respuesta).then(() => {
  }).catch(err => {
    console.error('Error al copiar la respuesta: ', err);
  });
}

document.addEventListener('DOMContentLoaded', () => {
  chrome.storage.sync.get(['apiKey', 'temperature', 'maxTokens'], (result) => {
    if (result.apiKey) API_KEY = result.apiKey;
    if (result.temperature) TEMPERATURE = result.temperature;
    if (result.maxTokens) MAX_TOKENS = result.maxTokens;

    document.getElementById('apiKey').value = API_KEY;
    document.getElementById('temperature').value = TEMPERATURE;
    document.getElementById('maxTokens').value = MAX_TOKENS;
  });

  document.getElementById('herramientasBtn').addEventListener('click', toggleHerramientasMenu);
  document.getElementById('guardarConfiguracion').addEventListener('click', guardarConfiguracion);
  document.getElementById('copiarRespuesta').addEventListener('click', copiarRespuesta);

  document.getElementById('enviar').addEventListener('click', async () => {
    const textoSeleccionado = document.getElementById('textoSeleccionado').textContent;
    const pregunta = document.getElementById('pregunta').value;
    const respuestaElement = document.getElementById('respuesta');

    respuestaElement.textContent = 'Generando respuesta...';

    try {
      const respuesta = await enviarPreguntaAGemini(textoSeleccionado, pregunta);
      respuestaElement.textContent = respuesta;
      document.getElementById('copiarRespuesta').style.display = 'block';
    } catch (error) {
      respuestaElement.textContent = 'Error al generar la respuesta.';
      console.error('Error:', error);
    }
  });

  chrome.storage.local.get(['textoSeleccionado'], async (result) => {
    const textoSeleccionado = result.textoSeleccionado || 'No hay texto seleccionado';
    document.getElementById('textoSeleccionado').textContent = textoSeleccionado;

    const preguntasAutomaticas = await generarPreguntasAutomaticas(textoSeleccionado);
    mostrarPreguntasAutomaticas(preguntasAutomaticas);
  });

  chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'local' && changes.textoSeleccionado) {
      document.getElementById('textoSeleccionado').textContent = changes.textoSeleccionado.newValue;
    }
  });
});


