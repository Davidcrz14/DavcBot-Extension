// Este archivo puede quedarse vacío o puedes eliminarlo si no lo necesitas para otras funcionalidades
