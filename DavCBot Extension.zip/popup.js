const API_KEY = "AIzaSyDsuQ-FWiCuBYzm7x-DdG3Cy0Eq1gyBkCY";
const API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent";

// Función para mostrar/ocultar el menú de herramientas
function toggleHerramientasMenu() {
  const menu = document.getElementById('herramientasMenu');
  menu.style.display = menu.style.display === 'none' ? 'block' : 'none';
}

// Función para guardar el nombre del usuario
function guardarNombre() {
  const nombre = document.getElementById('nombreUsuario').value.trim();
  if (nombre) {
    chrome.storage.sync.set({nombreUsuario: nombre}, () => {

      toggleHerramientasMenu(); // Ocultar el menú después de guardar
    });
  } else {
    alert('Por favor, ingresa un nombre válido');
  }
}

// Función para obtener el nombre del usuario
function obtenerNombre() {
  return new Promise((resolve) => {
    chrome.storage.sync.get(['nombreUsuario'], (result) => {
      resolve(result.nombreUsuario || '');
    });
  });
}

async function enviarPreguntaAGemini(contexto, pregunta) {
  const nombreUsuario = await obtenerNombre();
  try {
    const response = await fetch(`${API_URL}?key=${API_KEY}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        contents: [{
          parts: [{
            text: `Eres un asistente que siempre saluda diciendo "Hola ${nombreUsuario}!" al inicio de cada respuesta.\n\nContexto: ${contexto}\nPregunta: ${pregunta}`
          }]
        }],
        generationConfig: {
          temperature: 0.5,
        }
      }),
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    return data.candidates[0].content.parts[0].text;
  } catch (error) {
    console.error('Error al generar contenido:', error);
    throw error;
  }
}

document.addEventListener('DOMContentLoaded', () => {
  // Obtener el texto seleccionado almacenado
  chrome.storage.local.get(['textoSeleccionado'], (result) => {
    const textoSeleccionado = result.textoSeleccionado || 'No hay texto seleccionado';
    document.getElementById('textoSeleccionado').textContent = textoSeleccionado;
  });

  document.getElementById('enviar').addEventListener('click', () => {
    const pregunta = document.getElementById('pregunta').value;
    const textoSeleccionado = document.getElementById('textoSeleccionado').textContent;

    if (pregunta.trim() === '') {
      alert('Por favor, escribe una pregunta.');
      return;
    }

    document.getElementById('respuesta').textContent = 'Cargando respuesta...';

    enviarPreguntaAGemini(textoSeleccionado, pregunta)
      .then(respuesta => {
        document.getElementById('respuesta').textContent = respuesta;
      })
      .catch(error => {
        console.error('Error al obtener respuesta de Gemini:', error);
        document.getElementById('respuesta').textContent = 'Error al obtener respuesta. Por favor, intenta de nuevo.';
      });
  });

  // Agregar evento para mostrar/ocultar el menú de herramientas
  document.getElementById('herramientasBtn').addEventListener('click', toggleHerramientasMenu);

  // Agregar evento para guardar el nombre
  document.getElementById('guardarNombre').addEventListener('click', guardarNombre);

  // Cargar el nombre guardado al abrir el popup
  obtenerNombre().then(nombre => {
    document.getElementById('nombreUsuario').value = nombre;
  });

  // Agregar este listener para manejar la actualización del texto seleccionado
  chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'local' && changes.textoSeleccionado) {
      document.getElementById('textoSeleccionado').textContent = changes.textoSeleccionado.newValue;
    }
  });
});


